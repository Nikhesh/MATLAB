%Generation of spikes from sine wave
clc;
clear all;
close all;
% step 1: to generate square wave
t=linspace(0,1,100);
t1=linspace(0,1,99);
x=square(2*pi*5*t);
% step 2: differentiation of square wave
y=diff(x);
%plot the wave
subplot(2,1,1),plot(t,x),axis([0 1 -2 2]);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['square wave']);
subplot(2,1,2),plot(t1,y);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['spikes']);



