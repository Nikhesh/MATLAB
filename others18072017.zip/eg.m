clc;
clear all;
close all;
t=linspace(0,1,100);
x1=sin(2*pi*5*t);
x2=sin(2*pi*5*t.^2);
subplot(2,1,1),plot(t,x1);
subplot(2,1,2),plot(t,x2);