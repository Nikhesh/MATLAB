%Generation of unit sample sequences along with energies
clc;
clear all;
close all;
%To generate all x(n) 
n=[-5:5];
w=-2*(n==-1)+3*(n==0)+2*(n==1);
x=(n==-1)+(n==1);
y=2*(n==-1)+3*(n==0)-2*(n==1);
z=(n==-1)+3*(n==0)+(n==1);
%To compute the energy
E1=sum(abs(w).^2);
E2=sum(abs(x).^2);
E3=sum(abs(y).^2);
E4=sum(abs(z).^2);
%To plot all x(n)
subplot(2,2,1);
stem(n,w,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title(['x_1(n) of energy E_1= ',num2str(E1),' J']);
subplot(2,2,2);
stem(n,x,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title(['x_2(n) of energy E_2= ',num2str(E2),' J']);
subplot(2,2,3);
stem(n,y,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title(['x_3(n) of energy E_3= ',num2str(E3),' J']);
subplot(2,2,4);
stem(n,z,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title(['x_4(n) of energy E_4= ',num2str(E4),' J']);