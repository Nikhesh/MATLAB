%Generation of unit sample sequence
clc;
clear all;
close all;
n=[-5:5];
x=-1*(n==-1);
y=7*(n==0);
z=4*(n==1);
w=x+y+z;
%To compute the energy
E=sum(abs(w).^2);
stem(n,w,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title(['x(n) of energy E= ',num2str(E),' J']);