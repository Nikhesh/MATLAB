%To generate a ramp sequence
clc;
clear all;
close all;
n=-10:10;
x=(n+1).*(n+1>=0);
y=n.*(n>=0);
z=x-y;
subplot(3,1,1);
stem(n,x,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude'),title('r(n+1)');
subplot(3,1,2);
stem(n,y,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude'),title('r(n)');
subplot(3,1,3);
stem(n,z,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude'),title('u(n)');