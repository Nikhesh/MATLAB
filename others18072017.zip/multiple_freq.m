% Generation of sine waves of multiple frequencies
clc;
clear all;
close all;
t=linspace(0,1,100);
t1=linspace(0,1,300);
A=1;%amplitude
f1=0;
f2=5;
f3=10;%frequencies
p=0;%phase
%Generation of three sine waves of different frequencies
x1=A*sin(2*pi*f1*t+p);
x2=A*sin(2*pi*f2*t+p);
x3=A*sin(2*pi*f3*t+p);
y=[x3,x1,x2];
plot(t1,y);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['sine wave with multiple frequencies of ',num2str(f3),' , ',num2str(f1),' and ',num2str(f2)]);