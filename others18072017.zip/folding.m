%Generation of unit sample sequence
clc;
clear all;
close all;
n=[-5:5];
x=(n==0);
y=fliplr(x);
subplot(2,1,1)
stem(n,x,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title('\delta(n)');
subplot(2,1,2);
stem(n,y,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title('\delta(-n)');