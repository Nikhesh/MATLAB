%Adding noise to the sine signal
clc;
clear all;
close all;
%Generation of 1 Hz freq sine wave
t=linspace(0,1,100);
x=sin(2*pi*5*t);
%Noise generation
n1=rand(1,length(x));
n2=randn(1,length(x));
%Generation the corrupted signal
x1=x+n1;
x2=x+n2;
%filtering
% l=3;
% h=1/l*ones(1,l);
h=[0.5,-0.5];
y=filter(h,1,x1);
y1=filter(h,1,x2);
%Plot the original and corrupted signals
subplot(5,1,1),plot(t,x);
subplot(5,1,2),plot(t,x1);
subplot(5,1,3),plot(t,x2);
subplot(5,1,4),plot(t,y);
subplot(5,1,5),plot(t,y1);