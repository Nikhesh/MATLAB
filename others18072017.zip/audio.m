% To hear a sine wave
clc;
clear all;
close all;
t=linspace(0,1,8000);
x1=sin(2*pi*500*t.^2);
x2=sin(2*pi*1000*t.^2);
x3=sin(2*pi*1500*t.^2);
x=[x3,x2,x1];
soundsc(x)