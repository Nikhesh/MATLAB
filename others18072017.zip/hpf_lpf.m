%Generation of noisy signal and analyse in two filters
clc;
clear all;
close all;
%Generate a sqr wave
t=linspace(0,1,100);
x=square(2*pi*10*t);
%Generate random noise
n=rand(1,length(x));
%Create a noisy signal
s=x+n;
%LPF
h1=[0.5,0.5];
y1=filter(h1,1,s);
h2=[0.5,-0.5];
y2=filter(h2,1,s);
subplot(3,1,1),plot(t,s),axis([0 1 -2 2]);
subplot(3,1,2),plot(t,y1);
subplot(3,1,3),plot(t,y2);