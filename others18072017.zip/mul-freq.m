%Generating a sine wave of different frequencies
clc;
clear all;
close all;
t=[0,1,100];
t1=[0,1,300];
f1=5;
f2=0;
f3=10;
x1=sin(2*pi*f1*t);
x2=sin(2*pi*f2*t);
x3=sin(2*pi*f3*t);
y=[x1,x2,x3];
plot(t1,y);
xlabel('time(s)'),ylabel('Amplitude(V)'),title('sine wave of frequencies ',f1,'Hz,',f2,' Hz and',f3,'Hz');


