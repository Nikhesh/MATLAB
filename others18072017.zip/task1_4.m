%Generation of unit sample sequence
clc;
clear all;
close all;
n=[-5:5];
x=(n==-1);
y=5*(n==0);
z=-2*(n==1);
w=x+y+z;
stem(n,w,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title('x(n)');