%To generate unit step function and obtain its delayed version
clc;
clear all;
close all;
%Creating step function 
n=-5:5;
x=5*(-n-1>=0);
x1=5*(-n+1>=0);
%Plotting the step and delayed functions
subplot(2,1,1);
stem(n,x,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n-1)');
subplot(2,1,2);
stem(n,x1,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n+1)');
