%Generation of unit sample sequence
clc;
clear all;
close all;
n=[-5:5];
x=(n==0);
stem(n,x,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title('\delta(n)');