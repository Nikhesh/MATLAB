%Generation of unit sample sequence with del(n-2)
clc;
clear all;
close all;
n=[-5:5];
x=(n==-2);
stem(n,x,'fill','--','linewidth',2);
xlabel('n');
ylabel('Amplitude');title('\delta(n)');