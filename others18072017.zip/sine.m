% To generate continuous time signal with amplitude 1V, frquency=5Hz, phase=0 
clc;
clear all;
close all;
t=linspace(0,1,100);
A=1;%amplitude
f=5;%frequency
p=0;%phase
x=A*sin(2*pi*f*t+p);
%plot the wave
plot(t,x);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['sine wave with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);


