%Generation of square wave
clc;
clear all;
close all;
t=linspace(0,1,1000);
A=1;%amplitude
f=5;%frequency
p=0;%phase
x=A*sin(2*pi*f*t+p);
%conversion of sine to square wave
y=(x>=0);
%plot the wave
subplot(2,1,1),plot(t,x);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['sine wave with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);
subplot(2,1,2),plot(t,y),axis([0 1 -2 2]);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['square wave with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);



