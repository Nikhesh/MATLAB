%To generate unit step function and obtain its time reversal
clc;
clear all;
close all;
%Creating step function 
n=-10:10;
x=5*(n>=0);
%creating the folded version of step function
y=fliplr(x);
%Plotting the step and folded functions
subplot(2,1,1);
stem(n,x,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n)');
subplot(2,1,2);
stem(n,y,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(-n)');
