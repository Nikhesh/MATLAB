%To generate unit step function and obtain its delayed version
clc;
clear all;
close all;
%Creating step function 
n=-10:10;
x=(n>=0);
x1=-(n-1>=0);
y=x+x1;
%Plotting the step and delayed functions
subplot(3,1,1);
stem(n,x,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n+5)');
subplot(3,1,2);
stem(n,x1,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n-5)');
subplot(3,1,3);
stem(n,y,'fill','linewidth',2);
xlabel('n'),ylabel('Amplitude');
title('u(n+5)-u(n-5)');
