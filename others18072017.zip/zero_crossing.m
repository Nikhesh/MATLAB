%Generation of square wave
clc;
clear all;
close all;
t=linspace(0,1,1000);
A=1;%amplitude
f=5;%frequency
p=0;%phase
zcr=0;
x=A*sin(2*pi*f*t+p);
if(x==0)
    if(t==0)
    zcr=zcr+1;
    end
end
disp(zcr)




