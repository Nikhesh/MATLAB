% Generation of sine waves of multiple frequencies
clc;
clear all;
close all;
t=linspace(0,1,1000);
A=1;%amplitude
f1=0;
f2=5;
f3=10;%frequencies
p=0;%phase
%Generation of three sine waves of different frequencies
x1=A*sin(2*pi*f1*t+p);
x2=A*sin(2*pi*f2*t+p);
x3=A*sin(2*pi*f3*t+p);
y=x1+x2+x3;
plot(t,y)