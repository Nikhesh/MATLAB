%Generation of halfwave and fullwave rectified waveform of a sine wave
clc;
clear all;
close all;
t=linspace(0,1,1000);
A=1;%amplitude
f=5;%frequency
p=0;%phase
x=A*sin(2*pi*f*t+p);
%To obtain halfwave rectified output
y1=0.5*(x+abs(x));
%To obtain fullwave rectified output
y2=abs(x);
%plot the wave
subplot(3,1,1),plot(t,x);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['sine wave with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);
subplot(3,1,2),plot(t,y1);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['halfwave rectified output with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);
subplot(3,1,3),plot(t,y2);
xlabel('time(s)'),ylabel('amplitude(V)');
title(['fullwave rectified output with frequency ',num2str(f),'Hz ,with amplitude ',num2str(A),'V and phase \phi=',num2str(p),'^o']);



