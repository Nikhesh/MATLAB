clc;
clear all;
close all;
n=-10:10;
a=1/2;
x=(a.^n).*(n>=0);
stem(x)