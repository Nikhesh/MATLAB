%Histogram of rand function
clc;
clear all;
close all;
x1=randn(10000,1);
x2=randn(10000,1);
[p,q]=hist(x1,10);
[a,b]=hist(x2,10);
subplot(3,1,1),plot(x);
subplot(3,1,2),bar(q,p)%Plotting the histogram
subplot(3,1,3),bar(b,a)