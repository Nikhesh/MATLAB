%Generation of spikes and triangular wave from sine wave
clc;
clear all;
close all;
% step 1: to generate square wave
t=linspace(0,1,100);
t1=linspace(0,1,99);
x=square(2*pi*5*t);
% step 2: differentiation of square wave
choice=input('Enter 1 for differentiation and 2 for integration');
switch(choice)
    case 1
        y=diff(x);
        subplot(2,1,1),plot(t,x),axis([0 1 -2 2]);
        xlabel('time(s)'),ylabel('amplitude(V)');
        title(['square wave']);
        subplot(2,1,2),plot(t1,y);
        xlabel('time(s)'),ylabel('amplitude(V)');
        title(['spikes']);
    case 2
        y=cumsum(x);
        subplot(2,1,1),plot(t,x),axis([0 1 -2 2]);
        xlabel('time(s)'),ylabel('amplitude(V)');
        title(['square wave']);
        subplot(2,1,2),plot(t,y);
        xlabel('time(s)'),ylabel('amplitude(V)');
        title(['triangular wave']);
    otherwise
        disp('invalid choice');
end



