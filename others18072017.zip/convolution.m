%To prove convolution theorem
clc;
clear all;
close all;
%To generate sine wave
t=linspace(0,1,100);
x=square(2*pi*10*t)
%To generate del(n)
d=[zeros(1,19),1,zeros(1,80)];
y=filter(d,1,x);
subplot(3,1,1),plot(t,x),axis([0 1 -2 2]);
title('Input signal x(n)');
subplot(3,1,2),stem(d,'fill');
title('Convolution signal')
subplot(3,1,3),plot(t,y),axis([0 1 -2 2]);
title('Output signal y(n)');