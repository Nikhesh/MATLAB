%Impact of HPF
clc
clear all
close all
%Read the input image
im=imread('rice.png')
